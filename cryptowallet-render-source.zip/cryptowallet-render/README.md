# VAULT — Crypto Wallet (Render PostgreSQL)

A mobile-first Next.js wallet starter based on the supplied black/orange wallet reference. The included application supports account registration/login, a user wallet view, deposit requests, withdrawal requests with server-calculated fees and reserved balances, a separate admin login, user listing, audited balance adjustments, and withdrawal-fee settings.

> **Important operating boundary:** this repository is a sandbox ledger, not a custodian, exchange, payment processor, or blockchain wallet. `SANDBOX_MODE=true` is the default. Deposit requests do not credit balances until an administrator confirms them. Withdrawals reserve funds but are not broadcast to a blockchain. The demo UI intentionally does not show a fake deposit address, QR code, live BTC conversion, or completed on-chain transfer. Do not accept customer funds or market this as a live wallet until a qualified security review and a real custody/payment provider integration have been completed.

## Stack

- Next.js App Router + React + TypeScript
- Tailwind CSS + Lucide React
- Render Managed PostgreSQL (`pg`)
- Signed, HTTP-only JWT session cookie (`jose`)
- bcrypt password hashing and Zod input validation
- PostgreSQL NUMERIC columns for money (no floating-point database storage)

## Local setup

Requirements: Node.js 22+, npm, PostgreSQL 14+.

```bash
cp .env.example .env.local
# Set DATABASE_URL to a local PostgreSQL connection string.
# Generate SESSION_SECRET: openssl rand -base64 48
npm install
npm run db:migrate
npm run db:seed
npm run dev
```

Open http://localhost:3000. Register a user at `/register`. Admin login is at `/admin`.

The seed script requires `INITIAL_ADMIN_USERNAME` and `INITIAL_ADMIN_PASSWORD` (minimum 14 characters). It hashes the password with bcrypt and inserts the administrator only if the username does not already exist. The prompt's `@admin / @admin123` pair is deliberately **not** shipped as a production credential. Set your own values in `.env.local` and Render environment settings.

## Render deployment

1. Create a GitHub repository and push this project. Render's Blueprint flow requires the `render.yaml` file to be committed to the repository.
2. Open **https://dashboard.render.com/blueprint/new** and connect the repository.
3. Review the `cryptowallet-web` web service and `cryptowallet-db` PostgreSQL resource. The Blueprint attaches the database connection string as `DATABASE_URL`.
4. Set `APP_URL` to the deployed `https://<service>.onrender.com` URL.
5. Set `INITIAL_ADMIN_USERNAME` and a unique password of at least 14 characters. Do not use the sample values from documentation or commit secrets.
6. Keep `SANDBOX_MODE=true`. Apply the Blueprint. The build command runs the migration before building Next.js.
7. Once deployed, open `/admin` and sign in using the seeded admin credentials. Register a separate user account at `/register`.
8. Open the Render service Shell and run `npm run db:seed` once to create the initial administrator. The seed operation is idempotent for an existing username; changing an existing administrator password requires a separate password-rotation procedure.
9. Verify `https://<service>.onrender.com/api/health` returns `{ "ok": true, ... }`.

For a Render-hosted service, use the database **internal** connection string (the Blueprint does this). Keep the database and web service in the same Render region. Render PostgreSQL connection details are available in the database's Connect panel.

## Environment variables

| Variable | Required | Purpose |
|---|---:|---|
| `DATABASE_URL` | Yes | Render PostgreSQL connection string |
| `SESSION_SECRET` | Yes | At least 32 characters; signs sessions |
| `APP_URL` | Recommended | Canonical public application URL |
| `SANDBOX_MODE` | Yes | Keep `true` until real provider integration is implemented |
| `INITIAL_ADMIN_USERNAME` | Seed | Initial admin username |
| `INITIAL_ADMIN_PASSWORD` | Seed | Initial admin password, 14+ characters |

## API surface

- `POST /api/auth/register` — create a user and zero-balance USDT wallet
- `POST /api/auth/login` — user login
- `POST /api/auth/logout` — clear session
- `GET /api/wallet` — current user's wallet and latest transactions
- `POST /api/deposits` — create a pending deposit request (no balance credit)
- `POST /api/withdrawals` — validate limits/fee, lock wallet row, reserve total debit
- `POST /api/admin/login` — administrator login
- `GET /api/admin/overview` — aggregate operational counters
- `GET/PATCH /api/admin/users` — user list and audited suspend/reactivate
- `POST /api/admin/adjustments` — audited credit/debit adjustment with reason
- `GET/PUT /api/admin/settings` — withdrawal fee and limit settings
- `GET/PATCH /api/admin/deposits` — review pending deposit requests
- `GET/PATCH /api/admin/withdrawals` — review withdrawals; a transaction reference is required to mark completed
- `GET /api/admin/audit` — read-only recent audit log
- `GET /api/health` — health check

## Database and financial invariants

The initial migration creates users, admin_users, wallets, transactions, deposits, withdrawals, withdrawal_settings, deposit_settings, and admin_audit_logs. Monetary fields use PostgreSQL `NUMERIC(30,8)`. Withdrawal creation locks the user's wallet row and settings row in a transaction, calculates the fee on the server, and reserves the gross amount. Rejection releases the reservation. Deposit confirmation credits the wallet only inside the admin review transaction. Admin balance changes require a reason and create both a ledger transaction and audit entry.

## Production hardening still required

This is a deployable sandbox foundation, not a production-ready custody stack. Before any live financial use:

1. Integrate a regulated custody/payment provider and verify blockchain events server-to-server (confirmations, chain, token contract, amount, destination, replay protection, idempotency).
2. Implement signed webhook verification, idempotent event ingestion, reconciliation, and a proper double-entry ledger with immutable postings.
3. Add MFA/passkeys for admins, password reset and email verification, login throttling, IP/device risk controls, session revocation, and security alerting.
4. Add CSRF/origin enforcement to every state-changing endpoint, stricter rate limiting, request logging, CSP/security headers, and automated dependency/security scans.
5. Replace the simple admin list view with full review workflows, pagination, role scoping, export controls, and immutable audit-log access controls.
6. Conduct independent penetration testing, financial controls review, legal/compliance review, backup/restore testing, and incident-response planning.
7. Do not switch `SANDBOX_MODE` to `false` until all live integrations and operational controls have been implemented and independently tested. That flag alone does not enable live payments.

## Notes

- The BTC equivalent is shown as zero until a verified price feed and conversion service are integrated. The USDT asset quantity is sourced from the authenticated wallet balance.
- The `deposit_settings` table is provisioned for future verified address configuration, but no address is exposed to end users until a provider integration exists.
- A withdrawal marked completed requires a transaction hash/reference in the admin endpoint. In a real integration, this must be validated against the configured chain/provider, not merely entered as text.
