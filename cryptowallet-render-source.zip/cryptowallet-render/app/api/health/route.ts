import { NextResponse } from 'next/server';import { db } from '@/lib/db';
export async function GET(){try{await db.query('SELECT 1');return NextResponse.json({ok:true,service:'cryptowallet',mode:process.env.SANDBOX_MODE==='false'?'live-integrations-required':'sandbox'});}catch{return NextResponse.json({ok:false},{status:503})}}
