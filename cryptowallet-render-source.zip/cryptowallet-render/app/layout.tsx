import './globals.css';import type { Metadata } from 'next';
export const metadata:Metadata={title:'Vault — Crypto Wallet',description:'Minimal cryptocurrency wallet dashboard'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="pt-BR"><body>{children}</body></html>}
