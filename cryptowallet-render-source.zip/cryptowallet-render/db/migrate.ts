import { readFile } from 'node:fs/promises';
import { Pool } from 'pg';
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_URL?.includes('localhost') ? false : { rejectUnauthorized: false } });
async function main(){ const sql=await readFile(new URL('./migrations/001_init.sql',import.meta.url),'utf8'); await pool.query(sql); console.log('Database migration complete.'); await pool.end(); }
main().catch(async e=>{console.error(e);await pool.end();process.exit(1)});
