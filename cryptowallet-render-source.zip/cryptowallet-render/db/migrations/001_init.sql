CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS users (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), full_name TEXT NOT NULL, username TEXT NOT NULL UNIQUE,
 email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','suspended')),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS admin_users (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), username TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL,
 role TEXT NOT NULL DEFAULT 'admin' CHECK(role IN ('admin','superadmin')), active BOOLEAN NOT NULL DEFAULT true, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS wallets (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID NOT NULL REFERENCES users(id), asset TEXT NOT NULL DEFAULT 'USDT',
 available NUMERIC(30,8) NOT NULL DEFAULT 0 CHECK(available >= 0), in_use NUMERIC(30,8) NOT NULL DEFAULT 0 CHECK(in_use >= 0),
 UNIQUE(user_id,asset)
);
CREATE TABLE IF NOT EXISTS transactions (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID NOT NULL REFERENCES users(id), wallet_id UUID NOT NULL REFERENCES wallets(id),
 kind TEXT NOT NULL CHECK(kind IN ('deposit','withdrawal','admin_credit','admin_debit','hold','release')),
 amount NUMERIC(30,8) NOT NULL CHECK(amount > 0), fee NUMERIC(30,8) NOT NULL DEFAULT 0,
 status TEXT NOT NULL CHECK(status IN ('pending','confirmed','rejected','processing','completed')),
 reference TEXT NOT NULL UNIQUE, note TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS deposits (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID NOT NULL REFERENCES users(id), wallet_id UUID NOT NULL REFERENCES wallets(id),
 asset TEXT NOT NULL DEFAULT 'USDT', network TEXT NOT NULL, amount NUMERIC(30,8) NOT NULL CHECK(amount > 0),
 tx_hash TEXT, status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','confirmed','rejected')),
 reference TEXT NOT NULL UNIQUE, admin_note TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), reviewed_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS withdrawals (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id UUID NOT NULL REFERENCES users(id), wallet_id UUID NOT NULL REFERENCES wallets(id),
 asset TEXT NOT NULL DEFAULT 'USDT', network TEXT NOT NULL, destination TEXT NOT NULL, amount NUMERIC(30,8) NOT NULL CHECK(amount > 0),
 fee NUMERIC(30,8) NOT NULL CHECK(fee >= 0), total_debit NUMERIC(30,8) NOT NULL CHECK(total_debit > 0),
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','processing','completed','rejected')),
 reference TEXT NOT NULL UNIQUE, tx_hash TEXT, admin_note TEXT, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), reviewed_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS withdrawal_settings (
 id INTEGER PRIMARY KEY DEFAULT 1 CHECK(id=1), fee_type TEXT NOT NULL DEFAULT 'fixed' CHECK(fee_type IN ('fixed','percentage')),
 fee_value NUMERIC(20,8) NOT NULL DEFAULT 1 CHECK(fee_value >= 0), min_amount NUMERIC(30,8) NOT NULL DEFAULT 5,
 max_amount NUMERIC(30,8) NOT NULL DEFAULT 10000, enabled_networks TEXT[] NOT NULL DEFAULT ARRAY['TRC20','ERC20'], updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS deposit_settings (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), asset TEXT NOT NULL DEFAULT 'USDT', network TEXT NOT NULL,
 deposit_address TEXT NOT NULL, instructions TEXT NOT NULL DEFAULT 'Send only the selected asset on the selected network.',
 min_amount NUMERIC(30,8) NOT NULL DEFAULT 1, active BOOLEAN NOT NULL DEFAULT false, created_at TIMESTAMPTZ NOT NULL DEFAULT now(), UNIQUE(asset,network)
);
CREATE TABLE IF NOT EXISTS admin_audit_logs (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(), admin_id UUID REFERENCES admin_users(id), action TEXT NOT NULL,
 target_type TEXT, target_id TEXT, reason TEXT, before_data JSONB, after_data JSONB, ip_address TEXT,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_wallet_user ON wallets(user_id);
CREATE INDEX IF NOT EXISTS idx_transactions_user_date ON transactions(user_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_deposits_status_date ON deposits(status,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_withdrawals_status_date ON withdrawals(status,created_at DESC);
INSERT INTO withdrawal_settings(id) VALUES(1) ON CONFLICT DO NOTHING;
-- Financial rows are written only by server routes using the database owner connection. Do not expose DATABASE_URL to clients.
