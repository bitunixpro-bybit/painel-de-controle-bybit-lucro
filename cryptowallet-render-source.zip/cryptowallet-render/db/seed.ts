import { Pool } from 'pg'; import bcrypt from 'bcryptjs';
const pool=new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.DATABASE_URL?.includes('localhost')?false:{rejectUnauthorized:false}});
async function main(){const username=process.env.INITIAL_ADMIN_USERNAME;const password=process.env.INITIAL_ADMIN_PASSWORD;if(!username||!password||password.length<14)throw new Error('Set INITIAL_ADMIN_USERNAME and a password of at least 14 characters.');const hash=await bcrypt.hash(password,12);await pool.query('INSERT INTO admin_users(username,password_hash) VALUES($1,$2) ON CONFLICT(username) DO NOTHING',[username,hash]);console.log(`Admin seed checked for ${username}.`);await pool.end()}
main().catch(async e=>{console.error(e);await pool.end();process.exit(1)});
