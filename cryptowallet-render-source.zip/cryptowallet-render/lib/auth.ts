import { SignJWT, jwtVerify } from 'jose';
import { cookies } from 'next/headers';
import { db } from './db';
const secret=()=>{const s=process.env.SESSION_SECRET;if(!s||s.length<32)throw new Error('SESSION_SECRET must contain at least 32 characters');return new TextEncoder().encode(s)};
export async function createSession(id:string,role:'user'|'admin'){const token=await new SignJWT({sub:id,role}).setProtectedHeader({alg:'HS256'}).setIssuedAt().setExpirationTime('8h').sign(secret());(await cookies()).set('wallet_session',token,{httpOnly:true,secure:process.env.NODE_ENV==='production',sameSite:'lax',path:'/',maxAge:8*60*60});}
export async function getSession(){try{const token=(await cookies()).get('wallet_session')?.value;if(!token)return null;const {payload}=await jwtVerify(token,secret());if(typeof payload.sub!=='string'||(payload.role!=='user'&&payload.role!=='admin'))return null;return {id:payload.sub,role:payload.role as 'user'|'admin'};}catch{return null}}
export async function requireUser(){const s=await getSession();if(!s||s.role!=='user')throw new Error('UNAUTHORIZED');const r=await db.query('SELECT id,status FROM users WHERE id=$1',[s.id]);if(!r.rowCount||r.rows[0].status!=='active')throw new Error('UNAUTHORIZED');return s;}
export async function requireAdmin(){const s=await getSession();if(!s||s.role!=='admin')throw new Error('UNAUTHORIZED');const r=await db.query('SELECT id,active FROM admin_users WHERE id=$1',[s.id]);if(!r.rowCount||!r.rows[0].active)throw new Error('UNAUTHORIZED');return s;}
