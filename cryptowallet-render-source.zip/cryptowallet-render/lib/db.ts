import { Pool } from 'pg';
const globalForPg = globalThis as unknown as { pgPool?: Pool };
export const db = globalForPg.pgPool ?? new Pool({ connectionString: process.env.DATABASE_URL, max: 10, ssl: process.env.DATABASE_URL?.includes('localhost') ? false : { rejectUnauthorized: false } });
if (process.env.NODE_ENV !== 'production') globalForPg.pgPool = db;
