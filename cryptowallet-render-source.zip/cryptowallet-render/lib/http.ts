import { NextResponse } from 'next/server';
export function jsonError(message:string,status=400){return NextResponse.json({error:message},{status});}
export function reference(prefix:string){return `${prefix}-${Date.now().toString(36).toUpperCase()}-${crypto.randomUUID().slice(0,8).toUpperCase()}`;}
export function isSandbox(){return process.env.SANDBOX_MODE!=='false';}
