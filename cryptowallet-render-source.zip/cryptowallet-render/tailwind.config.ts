import type { Config } from 'tailwindcss';
export default { content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'], theme: { extend: { colors: { ink:'#050505', panel:'#111214', muted:'#96989e', accent:'#f59e0b' } } }, plugins: [] } satisfies Config;
